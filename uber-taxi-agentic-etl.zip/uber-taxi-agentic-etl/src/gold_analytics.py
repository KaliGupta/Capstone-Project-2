from pyspark.sql.functions import *

from config import (
    gold_daily_path,
    gold_location_path,
    gold_payment_path
)

def get_gold_metrics(spark):

    daily_df = (
        spark.read
        .format("delta")
        .load(gold_daily_path)
    )

    vehicle_df = (
        spark.read
        .format("delta")
        .load(gold_location_path)
    )

    payment_df = (
        spark.read
        .format("delta")
        .load(gold_payment_path)
    )

    # =====================================================
    # OVERALL METRICS
    # =====================================================

    overall = (

        daily_df

        .agg(

            sum("total_bookings")
            .alias("total_bookings"),

            sum("total_revenue")
            .alias("total_revenue")

        )

        .first()

        .asDict()

    )

    if overall["total_bookings"]:

        overall["average_revenue_per_booking"] = round(

            overall["total_revenue"]
            /
            overall["total_bookings"],

            2

        )

    else:

        overall["average_revenue_per_booking"] = 0

    # =====================================================
    # TOP VEHICLE TYPES
    # =====================================================

    top_vehicle_types = [

        row.asDict()

        for row in

        vehicle_df

        .orderBy(
            desc("total_revenue")
        )

        .limit(10)

        .collect()

    ]

    # =====================================================
    # PAYMENT SUMMARY
    # =====================================================

    payment_summary = [

        row.asDict()

        for row in

        payment_df

        .orderBy(
            desc("total_revenue")
        )

        .collect()

    ]

    return {

        "overall": overall,

        "top_vehicle_types": top_vehicle_types,

        "payment_summary": payment_summary

    }