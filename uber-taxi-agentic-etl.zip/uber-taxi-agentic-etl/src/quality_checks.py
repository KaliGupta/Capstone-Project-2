from pyspark.sql.functions import *
from config import silver_path


def run_quality_checks(spark):

    df = (
        spark.read
        .format("delta")
        .load(silver_path)
    )

    row_count = df.count()

    # =====================================================
    # REQUIRED COLUMNS
    # =====================================================

    required_columns = [

        "Booking ID",
        "Date",
        "Time",
        "Booking Status",
        "Customer ID",
        "Vehicle Type",
        "Pickup Location",
        "Drop Location"

    ]

    null_counts = (

        df.select(

            [
                count(
                    when(
                        col(c).isNull(),
                        1
                    )
                ).alias(c)

                for c in required_columns
            ]

        )

        .first()

        .asDict()

    )

    # =====================================================
    # INVALID BOOKING VALUE
    # =====================================================

    invalid_booking_value = (

        df.filter(

            col("booking_value").isNotNull()

            &

            (
                col("booking_value") < 0
            )

        )

        .count()

    )

    # =====================================================
    # INVALID DISTANCE
    # =====================================================

    invalid_distance = (

        df.filter(

            col("ride_distance").isNotNull()

            &

            (
                col("ride_distance") < 0
            )

        )

        .count()

    )

    # =====================================================
    # INVALID DRIVER RATING
    # =====================================================

    invalid_driver_rating = (

        df.filter(

            col("driver_rating").isNotNull()

            &

            (

                (col("driver_rating") < 1)

                |

                (col("driver_rating") > 5)

            )

        )

        .count()

    )

    # =====================================================
    # INVALID CUSTOMER RATING
    # =====================================================

    invalid_customer_rating = (

        df.filter(

            col("customer_rating").isNotNull()

            &

            (

                (col("customer_rating") < 1)

                |

                (col("customer_rating") > 5)

            )

        )

        .count()

    )

    # =====================================================
    # DUPLICATE BOOKING ID
    # =====================================================

    duplicate_booking_ids = (

        df.groupBy("Booking ID")

        .count()

        .filter(
            col("count") > 1
        )

        .count()

    )

    # =====================================================
    # COMPLETED RIDE VALIDATION
    # =====================================================

    completed_missing_values = (

        df.filter(
            col("booking_status") == "COMPLETED"
        )

        .filter(

            col("booking_value").isNull()

            |

            col("ride_distance").isNull()

            |

            col("payment_method").isNull()

        )

        .count()

    )

    # =====================================================
    # FINAL STATUS
    # =====================================================

    passed = (

        row_count > 0

        and all(
            value == 0
            for value in null_counts.values()
        )

        and invalid_booking_value == 0

        and invalid_distance == 0

        and invalid_driver_rating == 0

        and invalid_customer_rating == 0

        and duplicate_booking_ids == 0

        and completed_missing_values == 0

    )

    return {

        "status":
            "passed"
            if passed
            else "failed",

        "row_count":
            row_count,

        "null_counts":
            null_counts,

        "duplicate_booking_ids":
            duplicate_booking_ids,

        "invalid_booking_value":
            invalid_booking_value,

        "invalid_distance":
            invalid_distance,

        "invalid_driver_rating":
            invalid_driver_rating,

        "invalid_customer_rating":
            invalid_customer_rating,

        "completed_missing_values":
            completed_missing_values

    }