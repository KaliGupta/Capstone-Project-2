from typing import TypedDict

from langchain_openai import AzureChatOpenAI
from langgraph.graph import StateGraph, START, END

from config import (
    foundry_endpoint,
    foundry_api_key,
    foundry_model
)

from etl_pipeline import run_etl
from quality_checks import run_quality_checks
from gold_analytics import get_gold_metrics

# =====================================================
# LLM CONFIGURATION
# =====================================================

llm = AzureChatOpenAI(
    azure_endpoint=foundry_endpoint,
    api_key=foundry_api_key,
    azure_deployment=foundry_model,
    api_version="2024-02-15-preview",
    temperature=0.3,
    max_retries=2,
    timeout=60
)

# =====================================================
# STATE
# =====================================================

class ETLState(TypedDict, total=False):

    query: str

    route: str

    etl_result: dict

    quality_result: dict

    analytics_result: dict

    answer: str

# =====================================================
# GRAPH
# =====================================================

def build_agent_graph(spark):

    # =================================================
    # SUPERVISOR AGENT
    # =================================================

    def supervisor_agent(state: ETLState):

        query = state["query"]

        prompt = f"""
        You are Supervisor Agent for an Uber Taxi ETL System.

        Choose exactly one route:

        run_etl
        quality
        analytics
        explain

        User Query:
        {query}

        Return only route name.
        """

        try:

            response = llm.invoke(prompt)

            route = response.content.strip().lower()

        except:

            route = ""

        allowed_routes = {

            "run_etl",
            "quality",
            "analytics",
            "explain"

        }

        if route not in allowed_routes:

            q = query.lower()

            if any(
                x in q
                for x in [
                    "run etl",
                    "execute etl",
                    "refresh pipeline",
                    "load data"
                ]
            ):

                route = "run_etl"

            elif any(
                x in q
                for x in [
                    "quality",
                    "null",
                    "duplicate",
                    "invalid",
                    "data quality"
                ]
            ):

                route = "quality"

            elif any(
                x in q
                for x in [
                    "revenue",
                    "analytics",
                    "booking",
                    "payment",
                    "vehicle",
                    "cancellation",
                    "rating"
                ]
            ):

                route = "analytics"

            else:

                route = "explain"

        return {
            "route": route
        }

    # =================================================
    # ETL AGENT
    # =================================================

    def etl_agent(state: ETLState):

        try:

            result = run_etl(spark)

            return {
                "etl_result": result
            }

        except Exception as exc:

            return {

                "etl_result": {

                    "status": "failed",

                    "error": str(exc)

                }

            }

    # =================================================
    # QUALITY AGENT
    # =================================================

    def quality_agent(state: ETLState):

        try:

            result = run_quality_checks(spark)

            return {
                "quality_result": result
            }

        except Exception as exc:

            return {

                "quality_result": {

                    "status": "failed",

                    "error": str(exc)

                }

            }

    # =================================================
    # ANALYTICS AGENT
    # =================================================

    def analytics_agent(state: ETLState):

        try:

            metrics = get_gold_metrics(spark)

            response = llm.invoke(
                f"""
                You are an Uber Business Analytics Agent.

                Use ONLY the provided metrics.

                Do not invent values.

                Metrics:

                {metrics}

                User Question:

                {state['query']}
                """
            )

            return {

                "analytics_result": metrics,

                "answer": response.content

            }

        except Exception as exc:

            return {

                "analytics_result": {

                    "status": "failed",

                    "error": str(exc)

                },

                "answer": str(exc)

            }

    # =================================================
    # EXPLANATION AGENT
    # =================================================

    def explanation_agent(state: ETLState):

        response = llm.invoke(
            f"""
            Explain the following Uber ETL concept clearly.

            Do not assume any data execution.

            Question:

            {state['query']}
            """
        )

        return {

            "answer": response.content

        }

    # =================================================
    # ROUTING FUNCTIONS
    # =================================================

    def after_etl(state: ETLState):

        result = state.get(
            "etl_result",
            {}
        )

        if result.get("status") == "success":

            return "quality"

        return "end"

    def after_quality(state: ETLState):

        if state.get("route") == "run_etl":

            return "analytics"

        return "end"

    # =================================================
    # GRAPH CREATION
    # =================================================

    builder = StateGraph(ETLState)

    builder.add_node(
        "supervisor",
        supervisor_agent
    )

    builder.add_node(
        "etl",
        etl_agent
    )

    builder.add_node(
        "quality",
        quality_agent
    )

    builder.add_node(
        "analytics",
        analytics_agent
    )

    builder.add_node(
        "explain",
        explanation_agent
    )

    builder.add_edge(
        START,
        "supervisor"
    )

    builder.add_conditional_edges(

        "supervisor",

        lambda state: state["route"],

        {

            "run_etl": "etl",

            "quality": "quality",

            "analytics": "analytics",

            "explain": "explain"

        }

    )

    builder.add_conditional_edges(

        "etl",

        after_etl,

        {

            "quality": "quality",

            "end": END

        }

    )

    builder.add_conditional_edges(

        "quality",

        after_quality,

        {

            "analytics": "analytics",

            "end": END

        }

    )

    builder.add_edge(
        "analytics",
        END
    )

    builder.add_edge(
        "explain",
        END
    )

    return builder.compile()