storage_account_name = "mlflow8849842988"
container_name = "uberride"
storage_account_key = "fydJyB8PkK8jUbQmYQNfkgJxmzv4MnCcdBc10WwoMQMZ+IcoSRSbyVYj4CVCOCDKuz1aMelAJlrk+AStgAWHqw=="


# Paste your Microsoft Foundry API key here.
foundry_api_key = "37oNzUNM6Ieeee1U70G58g0lWhFtW4R03MvFCqN34VcU0zFwRQdVJQQJ99CJACYeBjFXJ3w3AAAAACOGsqBa"
foundry_endpoint = "https://azure-ai-faundry01.services.ai.azure.com/openai/v1/responses"
foundry_model = "gpt-4.1-mini"

storage_base = f"abfss://{container_name}@{storage_account_name}.dfs.core.windows.net"

source_path = f"{storage_base}/ncr_ride_bookings"
base_path = f"{storage_base}/output"
bronze_path = f"{base_path}/bronze"
silver_path = f"{base_path}/silver"

gold_daily_path = f"{base_path}/gold/daily_trip_summary"
gold_location_path = f"{base_path}/gold/location_trip_summary"
gold_payment_path = f"{base_path}/gold/payment_type_trip_summary"

# "/Workspace/green-taxi-agentic-etl/data"