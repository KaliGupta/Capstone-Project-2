from pyspark.sql.functions import *

from config import (
    storage_account_name,
    storage_account_key,
    source_path,
    bronze_path,
    silver_path,
    gold_daily_path,
    gold_location_path,
    gold_payment_path
)

# =====================================================
# READ SOURCE
# =====================================================

def read_source(spark):

    spark.conf.set(
        f"fs.azure.account.key.{storage_account_name}.dfs.core.windows.net",
        storage_account_key
    )

    raw_df = (
        spark.read
        .option("header", True)
        .option("inferSchema", True)
        .option("nullValue", "null")
        .csv(source_path)
    )

    return raw_df


# =====================================================
# BRONZE
# =====================================================

def build_bronze(spark, raw_df):

    bronze_df = (
        raw_df
        .withColumn(
            "ingestion_timestamp",
            current_timestamp()
        )
        .withColumn(
            "source_file",
            input_file_name()
        )
    )

    (
        bronze_df.write
        .format("delta")
        .mode("overwrite")
        .option("overwriteSchema", "true")
        .save(bronze_path)
    )

    bronze_df = (
        spark.read
        .format("delta")
        .load(bronze_path)
    )

    return bronze_df


# =====================================================
# SILVER
# =====================================================

def build_silver(spark, bronze_df):

    silver_df = (

        bronze_df

        .withColumn(
            "pickup_datetime",
            to_timestamp(
                col("lpep_pickup_datetime"),
                "MM/dd/yyyy hh:mm:ss a"
            )
        )

        .withColumn(
            "dropoff_datetime",
            to_timestamp(
                col("lpep_dropoff_datetime"),
                "MM/dd/yyyy hh:mm:ss a"
            )
        )

        .withColumn(
            "trip_date",
            to_date(col("pickup_datetime"))
        )

        .withColumn(
            "trip_hour",
            hour(col("pickup_datetime"))
        )

        .withColumn(
            "trip_duration_minutes",
            round(
                (
                    unix_timestamp(col("dropoff_datetime"))
                    - unix_timestamp(col("pickup_datetime"))
                ) / 60,
                2
            )
        )

        .withColumn(
            "fare_amount",
            col("fare_amount").cast("double")
        )

        .withColumn(
            "total_amount",
            col("total_amount").cast("double")
        )

        .withColumn(
            "trip_distance",
            col("trip_distance").cast("double")
        )

        .withColumn(
            "passenger_count",
            col("passenger_count").cast("int")
        )

        .withColumn(
            "payment_type",
            col("payment_type").cast("int")
        )

    )

    silver_df = silver_df.filter(

        (col("VendorID").isNotNull())

        &

        (col("pickup_datetime").isNotNull())

        &

        (
            col("fare_amount").isNull()
            |
            (col("fare_amount") >= 0)
        )

        &

        (
            col("trip_distance").isNull()
            |
            (col("trip_distance") >= 0)
        )

        &

        (
            col("trip_duration_minutes").isNull()
            |
            (col("trip_duration_minutes") >= 0)
        )

    )

    silver_df = silver_df.dropDuplicates()

    (
        silver_df.write
        .format("delta")
        .mode("overwrite")
        .option("overwriteSchema", "true")
        .save(silver_path)
    )

    silver_df = (
        spark.read
        .format("delta")
        .load(silver_path)
    )

    return silver_df


# =====================================================
# GOLD
# =====================================================

def build_gold(spark, silver_df):

    daily_summary = (

        silver_df

        .groupBy("trip_date")

        .agg(

            count("*").alias(
                "total_trips"
            ),

            round(
                sum("total_amount"),
                2
            ).alias(
                "total_revenue"
            ),

            round(
                avg("trip_distance"),
                2
            ).alias(
                "avg_trip_distance"
            )

        )

    )

    (
        daily_summary.write
        .format("delta")
        .mode("overwrite")
        .option("overwriteSchema", "true")
        .save(gold_daily_path)
    )

    location_summary = (

        silver_df

        .groupBy("PULocationID")

        .agg(

            round(
                sum("total_amount"),
                2
            ).alias(
                "total_revenue"
            ),

            count("*").alias(
                "rides"
            )

        )

    )

    (
        location_summary.write
        .format("delta")
        .mode("overwrite")
        .option("overwriteSchema", "true")
        .save(gold_location_path)
    )

    payment_summary = (

        silver_df

        .groupBy("payment_type")

        .agg(

            round(
                sum("total_amount"),
                2
            ).alias(
                "total_revenue"
            ),

            count("*").alias(
                "total_trips"
            )

        )

    )

    (
        payment_summary.write
        .format("delta")
        .mode("overwrite")
        .option("overwriteSchema", "true")
        .save(gold_payment_path)
    )

    return {

        "daily_summary": daily_summary,

        "location_summary": location_summary,

        "payment_summary": payment_summary

    }


# =====================================================
# MAIN ETL
# =====================================================

def run_etl(spark):

    raw_df = read_source(spark)

    bronze_df = build_bronze(
        spark,
        raw_df
    )

    silver_df = build_silver(
        spark,
        bronze_df
    )

    gold_dfs = build_gold(
        spark,
        silver_df
    )

    return {

        "status": "success",

        "raw_rows":
            raw_df.count(),

        "bronze_rows":
            bronze_df.count(),

        "silver_rows":
            silver_df.count(),

        "daily_summary_rows":
            gold_dfs["daily_summary"].count(),

        "location_summary_rows":
            gold_dfs["location_summary"].count(),

        "payment_summary_rows":
            gold_dfs["payment_summary"].count()

    }